jQuery(document).on('click', '.btn-next',  function(){
	jQuery("#step"+jQuery(this).attr('step')).css('display','none');
	jQuery("#step"+jQuery(this).attr('next')).css('display','block');
        //alert (jQuery(this).attr('step')+' next '+jQuery(this).attr('next'));
    });

jQuery(document).on('click', '.btn-back',  function(){
	jQuery("#step"+jQuery(this).attr('step')).css('display','none');
	jQuery("#step"+jQuery(this).attr('back')).css('display','block');
        //alert (jQuery(this).attr('step')+' next '+jQuery(this).attr('next'));
    });