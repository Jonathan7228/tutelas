<?php
/*
	Plugin Name: Wizard Tutelas
	Description: Wizard encuesta para generar tutelas
	Author: aaa
	Version: 1.0
*/
require_once(plugin_dir_path( __FILE__ ).'shortcodes/test.php');
require_once(plugin_dir_path( __FILE__ ).'scripts.php');
//require_once(plugin_dir_path( __FILE__ ).'shortcodes/marketing_grader_results.php');